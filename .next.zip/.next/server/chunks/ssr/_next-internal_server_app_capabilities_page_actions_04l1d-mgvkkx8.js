module.exports=[63646,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_capabilities_page_actions_04l1d-mgvkkx8.js.map