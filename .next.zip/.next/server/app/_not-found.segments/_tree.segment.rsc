:HL["/_next/static/chunks/0brssb77hshfq.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":64,"c":"$Q2"}]]
0:{"b":"Y50oQKULwFhNTyQGfHNb8","t":{"t":{"s":"","h":16,"c":"$Q1"}}}
